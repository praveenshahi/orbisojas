(function() {
  'use strict';

  /* ------------------------------------------------
     NAV — transparent → solid on scroll
     ------------------------------------------------ */
  var nav = document.querySelector('.nav');
  var scrollHint = document.querySelector('.scroll-hint');

  window.addEventListener('scroll', function() {
    var y = window.scrollY;
    if (y > 60) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
    if (scrollHint) {
      scrollHint.style.opacity = Math.max(0, 0.35 - y / 300);
    }
  }, { passive: true });

  /* ------------------------------------------------
     MOBILE NAV TOGGLE
     ------------------------------------------------ */
  var toggle = document.querySelector('.nav-toggle');
  if (toggle) {
    toggle.addEventListener('click', function() {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
    document.querySelectorAll('.nav-links a').forEach(function(a) {
      a.addEventListener('click', function() {
        nav.classList.remove('open');
      });
    });
  }

  /* ------------------------------------------------
     WORD REVEAL SETUP
     ------------------------------------------------ */
  document.querySelectorAll('[data-reveal]').forEach(function(el) {
    var html = el.innerHTML;
    var parts = html.split(/(<br\s*\/?>|<span[^>]*>.*?<\/span>)/gi);
    var wrapped = parts.map(function(part) {
      if (/^<br/i.test(part)) return part;
      if (/^<span/i.test(part)) return '<span class="word">' + part + '</span>';
      return part.replace(/(\S+)/g, '<span class="word">$1</span>');
    }).join('');
    el.innerHTML = wrapped;
  });

  /* ------------------------------------------------
     CANVAS: STARS
     ------------------------------------------------ */
  var starsCanvas = document.querySelector('.hero-stars');
  var starsCtx = starsCanvas ? starsCanvas.getContext('2d') : null;
  var stars = [];

  function initStars() {
    if (!starsCanvas) return;
    starsCanvas.width = starsCanvas.offsetWidth;
    starsCanvas.height = starsCanvas.offsetHeight;
    stars = [];
    var count = Math.min(150, Math.floor(starsCanvas.width * starsCanvas.height / 8000));
    for (var i = 0; i < count; i++) {
      stars.push({
        x: Math.random() * starsCanvas.width,
        y: Math.random() * starsCanvas.height * 0.65,
        r: Math.random() * 1.4 + 0.3,
        phase: Math.random() * Math.PI * 2,
        speed: Math.random() * 0.003 + 0.001
      });
    }
  }

  function drawStars(t) {
    if (!starsCtx) return;
    starsCtx.clearRect(0, 0, starsCanvas.width, starsCanvas.height);
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var a = 0.3 + 0.7 * ((Math.sin(t * s.speed + s.phase) + 1) * 0.5);
      starsCtx.beginPath();
      starsCtx.arc(s.x, s.y, s.r, 0, 6.283);
      starsCtx.fillStyle = 'rgba(232,220,200,' + a + ')';
      starsCtx.fill();
    }
  }

  /* ------------------------------------------------
     CANVAS: PARTICLES (amber dust)
     ------------------------------------------------ */
  var partCanvas = document.querySelector('.hero-particles');
  var partCtx = partCanvas ? partCanvas.getContext('2d') : null;
  var particles = [];

  function initParticles() {
    if (!partCanvas) return;
    partCanvas.width = partCanvas.offsetWidth;
    partCanvas.height = partCanvas.offsetHeight;
    particles = [];
    var count = Math.min(35, Math.floor(partCanvas.width / 40));
    for (var i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * partCanvas.width,
        y: Math.random() * partCanvas.height,
        r: Math.random() * 1.8 + 0.4,
        vx: (Math.random() - 0.5) * 0.25,
        vy: -Math.random() * 0.4 - 0.08,
        a: Math.random() * 0.4 + 0.1
      });
    }
  }

  function drawParticles() {
    if (!partCtx) return;
    partCtx.clearRect(0, 0, partCanvas.width, partCanvas.height);
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      if (p.y < -10) { p.y = partCanvas.height + 10; p.x = Math.random() * partCanvas.width; }
      if (p.x < -10) p.x = partCanvas.width + 10;
      if (p.x > partCanvas.width + 10) p.x = -10;
      partCtx.beginPath();
      partCtx.arc(p.x, p.y, p.r, 0, 6.283);
      partCtx.fillStyle = 'rgba(192,138,44,' + p.a + ')';
      partCtx.fill();
    }
  }

  /* ------------------------------------------------
     ANIMATION LOOP
     ------------------------------------------------ */
  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function tick(t) {
    drawStars(t);
    drawParticles();
    requestAnimationFrame(tick);
  }

  initStars();
  initParticles();
  if (!reducedMotion) {
    requestAnimationFrame(tick);
  }

  var resizeTimer;
  window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
      initStars();
      initParticles();
    }, 200);
  });

  /* ------------------------------------------------
     PARALLAX (mouse-driven, desktop only)
     ------------------------------------------------ */
  (function() {
    if (window.innerWidth < 769 || reducedMotion) return;
    var hero = document.querySelector('.hero');
    if (!hero) return;

    var layers = [
      { el: document.querySelector('.hero-stars'), f: 0.015 },
      { el: document.querySelector('.hero-city--left'), f: -0.025 },
      { el: document.querySelector('.hero-city--right'), f: -0.025 },
      { el: document.querySelector('.hero-orb'), f: 0.05 },
      { el: document.querySelector('.hero-traveler'), f: 0.02 }
    ];

    var mx = 0, my = 0, cx = 0, cy = 0;

    hero.addEventListener('mousemove', function(e) {
      var rect = hero.getBoundingClientRect();
      mx = e.clientX - rect.left - rect.width / 2;
      my = e.clientY - rect.top - rect.height / 2;
    });
    hero.addEventListener('mouseleave', function() { mx = 0; my = 0; });

    function parallaxTick() {
      cx += (mx - cx) * 0.06;
      cy += (my - cy) * 0.06;
      for (var i = 0; i < layers.length; i++) {
        if (layers[i].el) {
          layers[i].el.style.setProperty('--px', (cx * layers[i].f) + 'px');
          layers[i].el.style.setProperty('--py', (cy * layers[i].f) + 'px');
        }
      }
      requestAnimationFrame(parallaxTick);
    }
    requestAnimationFrame(parallaxTick);
  })();

  /* ------------------------------------------------
     GSAP ANIMATIONS
     ------------------------------------------------ */
  gsap.registerPlugin(ScrollTrigger);

  var titleWords = document.querySelectorAll('.hero-title .word');
  var subWords = document.querySelectorAll('.hero-sub .word');
  var divider = document.querySelector('.hero-divider');

  if (titleWords.length) {
    var tl = gsap.timeline({ delay: 0.6 });

    tl.to(titleWords, {
      opacity: 1,
      y: 0,
      stagger: 0.1,
      duration: 0.55,
      ease: 'power2.out'
    });

    tl.to(divider, {
      opacity: 1,
      duration: 0.7,
      ease: 'power2.out'
    }, '-=0.2');

    tl.to(subWords, {
      opacity: 1,
      y: 0,
      stagger: 0.06,
      duration: 0.5,
      ease: 'power2.out'
    }, '-=0.3');
  }

  // Selector — fade in on scroll
  gsap.from('.sel-header', {
    scrollTrigger: { trigger: '.selector', start: 'top 80%' },
    opacity: 0, y: -20, duration: 0.7, ease: 'power2.out'
  });
  gsap.from('.sel-panel', {
    scrollTrigger: { trigger: '.selector', start: 'top 75%' },
    opacity: 0, stagger: 0.15, duration: 0.9, ease: 'power2.out'
  });

  // Selector — mouse-driven divider shift (desktop)
  (function() {
    var panels = document.querySelector('.sel-panels');
    var divider = document.querySelector('.sel-divider');
    if (!panels || !divider || window.innerWidth < 769) return;

    panels.addEventListener('mousemove', function(e) {
      var rect = panels.getBoundingClientRect();
      var x = (e.clientX - rect.left) / rect.width;
      divider.style.left = (30 + x * 40) + '%';
    });
    panels.addEventListener('mouseleave', function() {
      divider.style.left = '50%';
    });
  })();

  // Selector — tap toggle (mobile)
  (function() {
    if (window.innerWidth >= 769) return;
    var selector = document.querySelector('.selector');
    var panels = document.querySelectorAll('.sel-panel');
    if (!selector || !panels.length) return;

    panels.forEach(function(panel) {
      panel.addEventListener('click', function(e) {
        var isBoy = panel.classList.contains('sel-panel--boy');
        var activeClass = isBoy ? 'boy-active' : 'girl-active';
        var wasActive = selector.classList.contains(activeClass);
        selector.classList.remove('boy-active', 'girl-active');
        if (!wasActive) {
          selector.classList.add(activeClass);
          e.preventDefault();
        }
      });
    });
  })();

})();
