/* ============================================================
   ORBISOJAS — Motion System
   "Everything enters from depth — opacity 0→1, translateY"
   No bounce. No side-slide. No rotation. No loop except pulse.
   ============================================================ */
gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

/* --- Word-by-word reveal for [data-reveal] elements --- */
document.querySelectorAll('[data-reveal]').forEach(function(el) {
  var html = el.innerHTML;
  var wrapped = html.replace(/(\S+)/g, '<span class="word">$1</span>');
  el.innerHTML = wrapped;
});

/* --- Descent meter --- */
(function() {
  var fill = document.querySelector('.descent-fill');
  if (!fill) return;
  window.addEventListener('scroll', function() {
    var h = document.documentElement.scrollHeight - window.innerHeight;
    if (h > 0) fill.style.height = (window.scrollY / h * 100) + '%';
  });
})();

/* --- Nav scroll state --- */
ScrollTrigger.create({
  start: 60,
  onUpdate: function(self) {
    document.querySelector('.nav').classList.toggle('nav--scrolled', self.scroll() > 60);
  }
});

/* --- Mobile nav toggle --- */
(function() {
  var btn = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (!btn || !links) return;
  btn.addEventListener('click', function() { links.classList.toggle('open'); });
  links.querySelectorAll('a').forEach(function(a) {
    a.addEventListener('click', function() { links.classList.remove('open'); });
  });
})();

/* --- Smooth anchor links --- */
document.querySelectorAll('a[href^="#"]').forEach(function(link) {
  link.addEventListener('click', function(e) {
    var t = document.querySelector(this.getAttribute('href'));
    if (t) {
      e.preventDefault();
      gsap.to(window, { scrollTo: { y: t, offsetY: 56 }, duration: 1.2, ease: 'power3.inOut' });
    }
  });
});

/* ============================================================
   SCENE 01 — THE BOY
   Fade from deep. Slow. Intimate.
   ============================================================ */
(function() {
  var tl = gsap.timeline({
    scrollTrigger: { trigger: '#boy', start: 'top 80%', once: true }
  });

  tl.to('#boy .scene-panel', { opacity: 1, duration: 1.2, ease: 'power2.out' })
    .from('#boy .scene-num', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.6')
    .from('#boy .scene-title', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.4');

  // Word-by-word reveal for lead text
  ScrollTrigger.create({
    trigger: '#boy',
    start: 'top 60%',
    once: true,
    onEnter: function() {
      gsap.to('#boy .scene-lead .word', {
        opacity: 1, y: 0,
        duration: 0.4,
        stagger: 0.08,
        ease: 'power2.out'
      });
    }
  });

  // Whisper text fades in from depth
  gsap.utils.toArray('#boy .scene-whisper').forEach(function(el, i) {
    gsap.from(el, {
      opacity: 0, y: 12,
      duration: 1,
      delay: 0.3 * i,
      ease: 'power2.out',
      scrollTrigger: { trigger: '#boy', start: 'top 45%', once: true }
    });
  });

  // Floating tags — emerge from depth, then drift gently
  gsap.utils.toArray('.ftag').forEach(function(tag, i) {
    gsap.to(tag, {
      opacity: 1,
      duration: 1.2,
      delay: 1.5 + i * 0.25,
      ease: 'power2.out',
      scrollTrigger: { trigger: '#boy', start: 'top 70%', once: true },
      onComplete: function() {
        gsap.to(tag, {
          y: '-=5',
          duration: 3 + Math.random() * 2,
          repeat: -1,
          yoyo: true,
          ease: 'sine.inOut',
          delay: Math.random()
        });
      }
    });
  });

  // Clock — slow fade, then slow blink (breath rhythm)
  gsap.to('.clock-label', {
    opacity: 0.7,
    duration: 2,
    delay: 3,
    ease: 'power2.out',
    scrollTrigger: { trigger: '#boy', start: 'top 50%', once: true },
    onComplete: function() {
      gsap.to('.clock-label', {
        opacity: 0.3,
        duration: 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut'
      });
    }
  });

  // Scroll hint
  gsap.to('.scroll-hint', {
    opacity: 1,
    duration: 1.5,
    delay: 3,
    ease: 'power2.out'
  });
  window.addEventListener('scroll', function handler() {
    if (window.scrollY > 80) {
      gsap.to('.scroll-hint', { opacity: 0, duration: 0.6 });
      window.removeEventListener('scroll', handler);
    }
  });
})();

/* ============================================================
   SCENE 02 — THE SYSTEM
   Emerge from depth. Cards settle into place.
   ============================================================ */
(function() {
  var tl = gsap.timeline({
    scrollTrigger: { trigger: '#system', start: 'top 70%', once: true }
  });

  tl.to('#system .scene-panel', { opacity: 1, duration: 1.2, ease: 'power2.out' })
    .from('#system .scene-num', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.6')
    .from('#system .scene-title', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.4');

  ScrollTrigger.create({
    trigger: '#system',
    start: 'top 55%',
    once: true,
    onEnter: function() {
      gsap.to('#system .scene-lead .word', {
        opacity: 1, y: 0,
        duration: 0.4,
        stagger: 0.08,
        ease: 'power2.out'
      });
    }
  });

  gsap.utils.toArray('#system .scene-whisper').forEach(function(el, i) {
    gsap.from(el, {
      opacity: 0, y: 12,
      duration: 1,
      delay: 0.3 * i,
      ease: 'power2.out',
      scrollTrigger: { trigger: '#system', start: 'top 45%', once: true }
    });
  });

  // Metric cards — fade from depth, staggered settle
  gsap.utils.toArray('.metric-card').forEach(function(card, i) {
    gsap.fromTo(card,
      { opacity: 0, y: 16 },
      {
        opacity: 1, y: 0,
        duration: 0.7,
        delay: i * 0.07,
        ease: 'power2.out',
        scrollTrigger: { trigger: '#system .metric-grid', start: 'top 80%', once: true }
      }
    );
  });

  // Bar fill
  ScrollTrigger.create({
    trigger: '.mc-bar-fill',
    start: 'top 85%',
    once: true,
    onEnter: function() {
      document.querySelectorAll('.mc-bar-fill').forEach(function(b) { b.classList.add('animate'); });
    }
  });
})();

/* ============================================================
   SCENE 03 — THE TRUTH
   Text fades from center. Columns emerge from depth.
   ============================================================ */
(function() {
  var tl = gsap.timeline({
    scrollTrigger: { trigger: '#truth', start: 'top 70%', once: true }
  });

  tl.to('#truth .scene-panel', { opacity: 1, duration: 1.2, ease: 'power2.out' })
    .from('#truth .scene-num', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.6')
    .from('#truth .scene-title', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.4');

  ScrollTrigger.create({
    trigger: '#truth',
    start: 'top 55%',
    once: true,
    onEnter: function() {
      gsap.to('#truth .scene-lead .word', {
        opacity: 1, y: 0,
        duration: 0.4,
        stagger: 0.08,
        ease: 'power2.out'
      });
    }
  });

  // Truth columns — emerge from depth
  gsap.utils.toArray('.truth-col').forEach(function(col, i) {
    gsap.fromTo(col,
      { opacity: 0, y: 24 },
      {
        opacity: 1, y: 0,
        duration: 1,
        delay: i * 0.25,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.truth-columns', start: 'top 80%', once: true }
      }
    );
  });

  // List items — staggered fade in
  gsap.utils.toArray('.truth-col').forEach(function(col) {
    gsap.from(col.querySelectorAll('li'), {
      opacity: 0, y: 8,
      duration: 0.5,
      stagger: 0.12,
      ease: 'power2.out',
      scrollTrigger: { trigger: col, start: 'top 70%', once: true }
    });
  });

  // Layers diagram — fade in, then items cascade
  gsap.fromTo('.layers-diagram',
    { opacity: 0, y: 16 },
    {
      opacity: 1, y: 0,
      duration: 1,
      ease: 'power2.out',
      scrollTrigger: { trigger: '.layers-diagram', start: 'top 85%', once: true }
    }
  );
  gsap.utils.toArray('.layer-item').forEach(function(item, i) {
    gsap.fromTo(item,
      { opacity: 0, y: 10 },
      {
        opacity: 1, y: 0,
        duration: 0.7,
        delay: 0.5 + i * 0.2,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.layers-diagram', start: 'top 85%', once: true }
      }
    );
  });
})();

/* ============================================================
   SCENE 04 — THE JOURNEY
   Stages emerge one by one. CTA arrives last.
   ============================================================ */
(function() {
  var tl = gsap.timeline({
    scrollTrigger: { trigger: '#journey', start: 'top 70%', once: true }
  });

  tl.to('#journey .scene-panel', { opacity: 1, duration: 1.2, ease: 'power2.out' })
    .from('#journey .scene-num', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.6')
    .from('#journey .scene-title', { opacity: 0, y: 16, duration: 0.8, ease: 'power2.out' }, '-=0.4');

  ScrollTrigger.create({
    trigger: '#journey',
    start: 'top 55%',
    once: true,
    onEnter: function() {
      gsap.to('#journey .scene-lead .word', {
        opacity: 1, y: 0,
        duration: 0.4,
        stagger: 0.08,
        ease: 'power2.out'
      });
    }
  });

  // Journey line
  ScrollTrigger.create({
    trigger: '.journey-path',
    start: 'top 80%',
    once: true,
    onEnter: function() {
      document.querySelector('.journey-path').style.setProperty('--line-opacity', '0.3');
    }
  });

  // Stages — emerge from depth one by one
  gsap.utils.toArray('.jp-stage').forEach(function(stage, i) {
    gsap.fromTo(stage,
      { opacity: 0, y: 24 },
      {
        opacity: 1, y: 0,
        duration: 0.9,
        delay: 0.3 + i * 0.2,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.journey-path', start: 'top 80%', once: true }
      }
    );
  });

  // Connectors — subtle fade
  gsap.utils.toArray('.jp-connector').forEach(function(c, i) {
    gsap.fromTo(c,
      { opacity: 0 },
      {
        opacity: 0.5,
        duration: 0.6,
        delay: 0.5 + i * 0.2,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.journey-path', start: 'top 80%', once: true }
      }
    );
  });

  // CTA — final reveal
  gsap.fromTo('.journey-cta',
    { opacity: 0, y: 20 },
    {
      opacity: 1, y: 0,
      duration: 1.2,
      ease: 'power2.out',
      scrollTrigger: { trigger: '.journey-cta', start: 'top 90%', once: true }
    }
  );
})();

/* ============================================================
   GLOBAL — Parallax drift (desktop only)
   Background moves at different speed = depth perception
   ============================================================ */
if (window.innerWidth > 900) {
  gsap.utils.toArray('.scene').forEach(function(section) {
    gsap.fromTo(section,
      { backgroundPositionY: '35%' },
      {
        backgroundPositionY: '65%',
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 2
        }
      }
    );
  });
}
